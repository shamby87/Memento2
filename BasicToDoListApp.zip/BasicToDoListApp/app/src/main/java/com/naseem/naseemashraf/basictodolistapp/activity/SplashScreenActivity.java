package com.naseem.naseemashraf.basictodolistapp.activity;

import android.support.v7.app.AppCompatActivity;

public class SplashScreenActivity extends AppCompatActivity {



}
