package com.naseem.naseemashraf.basictodolistapp.UI;

public interface OnTaskAddListener {
    void onTaskAdded(String taskTitle, String taskContent);
    void onTaskUpdated(int taskID, String taskTitle, String taskContent);
}
