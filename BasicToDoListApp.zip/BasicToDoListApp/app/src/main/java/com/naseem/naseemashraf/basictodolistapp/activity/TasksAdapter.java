package com.naseem.naseemashraf.basictodolistapp.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.naseem.naseemashraf.basictodolistapp.R;
import com.naseem.naseemashraf.basictodolistapp.db.Task;

import java.util.Collections;
import java.util.List;

public class TasksAdapter extends RecyclerView.Adapter<TasksAdapter.TaskViewHolder> {

    private List<Task> taskList;

    public interface TasksAdapterCallback{
        void onTaskChecked(int position, boolean checkState);
        void onTaskSelected(int position);
    }
    TasksAdapterCallback callback;

    public class TaskViewHolder extends RecyclerView.ViewHolder {

        TextView tvTask;
        CheckBox chkDone;

        Context context;

        public TaskViewHolder(@NonNull final View itemView) {
            super(itemView);

            context = itemView.getContext();

            tvTask = (TextView) itemView.findViewById(R.id.tvTask);
            chkDone = (CheckBox) itemView.findViewById(R.id.chkDone);

            tvTask.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    callback.onTaskSelected(getLayoutPosition());
                }
            });

            chkDone.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
                        tvTask.setPaintFlags(tvTask.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                        if(callback != null) {
                            taskList.get(getLayoutPosition()).setChecked(true);
                            callback.onTaskChecked(getLayoutPosition(), true);
                        }
                    }else{
                        tvTask.setPaintFlags(tvTask.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                        if(callback != null) {
                            taskList.get(getLayoutPosition()).setChecked(false);
                            callback.onTaskChecked(getLayoutPosition(), false);
                        }
                    }
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int itemPos = getLayoutPosition();

                    String tid = Integer.toString(taskList.get(itemPos).getId());
                    String ttitle = taskList.get(itemPos).getTitle();
                    String tcontent = taskList.get(itemPos).getContent();
                    String tchecked = Boolean.toString(taskList.get(itemPos).isChecked());

                    Intent detailedTaskIntent = new Intent(context, TaskDetailActivity.class);
                    detailedTaskIntent.putExtra("tid",tid);
                    detailedTaskIntent.putExtra("ttitle",ttitle);
                    detailedTaskIntent.putExtra("tcontent",tcontent);
                    detailedTaskIntent.putExtra("tchecked",tchecked);
                }
            });
        }

    }

    public TasksAdapter(List<Task> taskListIn, TasksAdapterCallback callback) {
        this.taskList = taskListIn;
        this.callback = callback;
    }

    @Override
    public TasksAdapter.TaskViewHolder onCreateViewHolder(ViewGroup parent, int i) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_item_view, parent, false);

        return new TaskViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final TaskViewHolder taskViewHolder, int i) {
        final Task task = taskList.get(i);

        taskViewHolder.chkDone.setChecked(task.isChecked());
        taskViewHolder.tvTask.setText(task.getTitle());

        if(task.isChecked()) {
            taskViewHolder.tvTask.setPaintFlags(taskViewHolder.tvTask.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
    }

    @Override
    public int getItemCount() {
        return this.taskList.size();
    }

    public void removeTask(int position) {
        taskList.remove(position);
        notifyItemRemoved(position);
    }

    public void onTaskMove(int fromPosition, int toPosition){
        Collections.swap(taskList, fromPosition, toPosition);
        notifyItemMoved(fromPosition, toPosition);
    }

    public void restoreTask(Task task, int position) {
        taskList.add(position, task);
        notifyItemInserted(position);
    }

    public void updateTask(Task task, int index) {
        taskList.get(index).setTitle(task.getTitle());
        taskList.get(index).setContent(task.getContent());
        notifyItemChanged(index);
    }

    public void onTaskAdd(List<Task> inTaskList) {
        //taskList.add(task);
        this.taskList = inTaskList;
        notifyItemInserted(taskList.size());
    }
}
