package com.naseem.naseemashraf.basictodolistapp.db;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {Task.class}, version = 1)
public abstract class TasksSQLDatabase extends RoomDatabase {


    private static TasksSQLDatabase tasksSQLDatabase;

    public static TasksSQLDatabase getInstance(Context context){

        if(tasksSQLDatabase==null){
            tasksSQLDatabase = Room.databaseBuilder(context.getApplicationContext(),
                    TasksSQLDatabase.class, "tasks_table").build();
        }
        return tasksSQLDatabase;
    }

    public abstract TaskDAO taskDao();

}
