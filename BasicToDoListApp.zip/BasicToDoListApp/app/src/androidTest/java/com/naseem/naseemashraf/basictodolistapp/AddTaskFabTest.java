package com.naseem.naseemashraf.basictodolistapp;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.naseem.naseemashraf.basictodolistapp.activity.TaskActivity;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.espresso.IdlingRegistry;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.idling.CountingIdlingResource;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnitRunner;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.IsNot.not;

@RunWith(AndroidJUnit4.class)
public class AddTaskFabTest extends AndroidJUnitRunner {

    @Rule
    public ActivityTestRule<TaskActivity> mTaskActivityActivityTestRule =
            new ActivityTestRule<TaskActivity>(TaskActivity.class);

    @Before
    public void setUp() throws Exception{
        CountingIdlingResource countingResource = new CountingIdlingResource("RecyclerIdler");
        mTaskActivityActivityTestRule.getActivity().setIdlingResource(countingResource);
        IdlingRegistry.getInstance().register(countingResource);
        //registerIdlingResource(countingResource);
        //FooApplication.setFooServer(new DecoratedFooServer(realServer, countingResource));
    }

    @After
    public void cleanUp() throws Exception{
        CountingIdlingResource countingResource = mTaskActivityActivityTestRule.getActivity().getIdlingResource();
        IdlingRegistry.getInstance().unregister(countingResource);
        mTaskActivityActivityTestRule.getActivity().deleteDatabase("tasks_table");
    }

    @Test
    public void clickAddTaskFAB_opensAddTaskBottomSheetDialog() throws Exception {
        onView(withId(R.id.fab))
                .perform(click());

        onView(withId(R.id.bottom_sheet))
                .check(matches(isDisplayed()));
    }

    @Test
    public void addTask_saveTask_checkRecycler() throws Exception {
        onView(withId(R.id.fab))
                .perform(click());

        onView(withId(R.id.EditTextTitle))
                .perform(ViewActions.typeText("Test Task Title."))
                .perform(ViewActions.closeSoftKeyboard());

        onView(withId(R.id.ButtonSave))
                .perform(click());

        //onView(ViewMatchers.withId(R.id.tasks_recycler_view))
                //.perform(RecyclerViewActions.actionOnItemAtPosition(0,click());

        //onView(withId(R.id.EditTextTitle)).check(matches(isEditTextValueEqualTo("Task 1")));
        // First scroll to the position that needs to be matched and click on it.
        ////onView(ViewMatchers.withId(R.id.tasks_recycler_view))
            ////    .perform(RecyclerViewActions.actionOnItemAtPosition(0, click()));

        // Match the text in an item below the fold and check that it's displayed.
        ////String itemElementText = "Task 1";
        ////onView(withText(itemElementText)).check(matches(isDisplayed()));
    }

    @Test
    public void checkTaskRecyclerFirstItem() throws Exception{

        onView(withId(R.id.tasks_recycler_view))
                .perform(RecyclerViewActions.scrollToPosition(5)); //click()));*/

        onView(withId(R.id.tvTask)).check(matches(withText("Task 5")));

        /*onView(withId(R.id.tasks_recycler_view)).perform(
                RecyclerViewActions.actionOnItemAtPosition(0,
                        MyViewAction.clickChildViewWithId(R.id.tvTask)));*/

        /*onView(withId(R.id.EditTextTitle))
                .check(matches(isDisplayed()));*/

        /*onView(withId(R.id.EditTextTitle))
                .check(matches(isEditTextValueEqualTo("Task 0")));*/
    }

    /*
    @Test
    public void checkTaskRecyclerNewItem() throws Exception{
        onView(withId(R.id.tasks_recycler_view)).perform(
                RecyclerViewActions.actionOnItemAtPosition(10,
                        MyViewAction.clickChildViewWithId(R.id.tvTask)));

        onView(withId(R.id.EditTextTitle))
                .check(matches(isDisplayed()));

        onView(withId(R.id.EditTextTitle))
                .check(matches(isEditTextValueEqualTo("Test Task Title.")));
    }*/

    Matcher<View> isEditTextValueEqualTo(final String content) {

        return new TypeSafeMatcher<View>() {

            @Override
            public void describeTo(Description description) {
                description.appendText("Match Edit Text Value with View ID Value : :  " + content);
            }

            @Override
            public boolean matchesSafely(View view) {
                if (!(view instanceof TextView) && !(view instanceof EditText)) {
                    return false;
                }
                if (view != null) {
                    String text;
                    if (view instanceof TextView) {
                        text =((TextView) view).getText().toString();
                    } else {
                        text =((EditText) view).getText().toString();
                        Log.e("WAW","View Value is : "+text);
                    }

                    return (text.equalsIgnoreCase(content));
                }
                return false;
            }
        };
    }

    public static class MyViewAction {

        public static ViewAction clickChildViewWithId(final int id) {
            return new ViewAction() {
                @Override
                public Matcher<View> getConstraints() {
                    return null;
                }

                @Override
                public String getDescription() {
                    return "Click on a child view with specified id.";
                }

                @Override
                public void perform(UiController uiController, View view) {
                    View v = view.findViewById(id);
                    v.performClick();
                }
            };
        }

    }
}
