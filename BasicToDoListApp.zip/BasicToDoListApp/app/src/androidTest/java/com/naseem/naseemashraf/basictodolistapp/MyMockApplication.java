package com.naseem.naseemashraf.basictodolistapp;

import android.app.Application;

public class MyMockApplication extends Application {

}